window.searchPagePath = "search/";
