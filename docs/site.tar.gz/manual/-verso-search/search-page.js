/**
 * Copyright (c) 2026 Lean FRO LLC. All rights reserved.
 * Released under Apache 2.0 license as described in the file LICENSE.
 * Author: David Thrane Christiansen
 */

// Enable typescript
// @ts-check

import { domainMappers, searchPriorities } from "./domain-mappers.js";
import {
    buildSearchableMap,
    computeCandidates,
    renderCandidateLi,
    getDocContentsFor,
} from "./search-box.js";

const fuzzysort = /** @type {{fuzzysort: Fuzzysort.Fuzzysort}} */ (/** @type {unknown} */ (window))
    .fuzzysort;

/**
 * Lazy search state shared across renders. `xref.json` is fetched once, then reused for
 * every keystroke. Cached as a promise rather than a resolved value so a second call
 * arriving before the first `fetch` resolves joins the same in-flight request instead
 * of issuing a duplicate.
 * @type {null | Promise<{
 *   preparedData: Fuzzysort.Prepared[],
 *   mappedData: any,
 *   searchPriorities: any,
 *   docPriorities: Record<string, number>,
 *   searchIndex: any,
 * }>}
 */
let statePromise = null;

/**
 * True once `statePromise` has resolved. Used to suppress the "Searching…" placeholder
 * on post-load renders: once the index is in memory, each keystroke resolves on the next
 * microtask and flashing "Searching…" every time produces visible flicker.
 */
let stateReady = false;

const ensureState = () =>
    (statePromise ??= (async () => {
        const json = await fetch("xref.json").then((r) => r.json());
        const mappedData = buildSearchableMap(json, domainMappers);
        const preparedData = Object.keys(mappedData).map((name) => fuzzysort.prepare(name));
        const state = {
            preparedData,
            mappedData,
            searchPriorities: {
                semantic: searchPriorities?.semantic ?? 50,
                fullText: searchPriorities?.fullText ?? 50,
                domains: searchPriorities?.domains ?? {},
            },
            docPriorities: /** @type {any} */ (window).docPriorities ?? {},
            searchIndex: /** @type {any} */ (window).searchIndex,
        };
        stateReady = true;
        return state;
    })());

/**
 * Monotonic token: every call to `renderResultsFor` bumps it. The async render loop
 * checks the token after each `await` and bails if a newer render has started, so a
 * user who keeps typing doesn't see stale partial results appended to the list.
 */
let renderToken = 0;

/** Cached references to the count + list containers. */
let countEl = /** @type {HTMLParagraphElement | null} */ (null);
let listEl = /** @type {HTMLUListElement | null} */ (null);

/**
 * Active domain/fullText filter state. Initialized once, mutated in place as the user
 * toggles checkboxes; the render loop reads the current values on every pass.
 * @type {{ domains: Set<string>, fullText: boolean }}
 */
const filters = { domains: new Set(Object.keys(domainMappers)), fullText: true };

/**
 * Handles for every filter checkbox + its label so we can flip them to disabled/gray
 * when the current query has no hits in that bucket.
 * @type {{ fullText: null | {cb: HTMLInputElement, label: HTMLLabelElement},
 *          domains: Record<string, {cb: HTMLInputElement, label: HTMLLabelElement}> }}
 */
const filterElements = { fullText: null, domains: {} };

/**
 * Set the result-count text. Kept at the top of the results region regardless of which
 * render branch runs, so users always see the count (or the empty-state message).
 *
 * @param {string} text
 * @param {boolean} muted
 */
const setCount = (text, muted = false) => {
    if (!countEl) return;
    countEl.textContent = text;
    countEl.classList.toggle("muted", muted);
};

/**
 * Replace the results list with results for `query`. `""` shows the empty-state
 * placeholder and hides the list.
 *
 * @param {string} query
 */
const renderResultsFor = async (query) => {
    if (!countEl || !listEl) return;

    const myToken = ++renderToken;

    if (!query) {
        listEl.textContent = "";
        setCount("Type a query in the search box to see results.", true);
        clearFilterDisabled();
        return;
    }

    // Only show "Searching…" on the cold first render. After the index is in memory,
    // `ensureState()` resolves on the next microtask and the existing count would flash
    // to "Searching…" for a single frame on every keystroke.
    if (!stateReady) setCount("Searching…", true);
    const state = await ensureState();
    if (myToken !== renderToken) return;

    const allCandidates = computeCandidates(query, state);
    if (myToken !== renderToken) return;

    // Per-bucket counts over the unfiltered pool drive the "no results for this filter"
    // grayed-out state of each checkbox.
    const counts = { fullText: 0, domains: /** @type {Record<string, number>} */ ({}) };
    for (const c of allCandidates) {
        if (c.kind === "semantic") {
            const id = c.searchable.domainId;
            counts.domains[id] = (counts.domains[id] ?? 0) + 1;
        } else {
            counts.fullText++;
        }
    }
    updateFilterDisabled(counts);

    const candidates = allCandidates.filter((c) =>
        c.kind === "semantic" ? filters.domains.has(c.searchable.domainId) : filters.fullText,
    );

    const n = candidates.length;
    const total = allCandidates.length;
    if (n === total) {
        setCount(`${n} result${n === 1 ? "" : "s"}`);
    } else {
        setCount(`${n} of ${total} result${total === 1 ? "" : "s"}`);
    }

    listEl.textContent = "";
    if (n === 0) return;

    // The full-page view has room for wider snippets and more of them than the
    // cramped combobox dropdown does; these tune the per-result excerpt sizes.
    const textSnippet = { header: 60, content: 60, maxSnippets: 5 };

    // Mount the first `EAGER` results synchronously, then schedule the rest for idle
    // time. On broad queries the full list can be 500+ items, and compositor cost on
    // slow machines scales with DOM size — deferring the tail keeps keystroke latency
    // low. The count paragraph already reflects `n` (the full total), so Ctrl-F /
    // screen-reader counts aren't misleading while the tail is still filling in.
    //
    // `CHUNK` controls fragment-batch size: each chunk builds a DocumentFragment and
    // appends it in one shot, so the browser commits once per chunk instead of once
    // per result. Serial `await` inside a chunk is still required — full-text results
    // load their bucket lazily and depend on that resolving.
    const EAGER = 200;
    const CHUNK = 20;

    /**
     * Render candidates [start, end) into a DocumentFragment, appending to `listEl`
     * at the end. Returns false if the render was cancelled mid-way by a newer query.
     * @param {number} start
     * @param {number} end
     * @return {Promise<boolean>}
     */
    const renderChunk = async (start, end) => {
        const frag = document.createDocumentFragment();
        for (let i = start; i < end; i++) {
            if (myToken !== renderToken) return false;
            const li = await renderCandidateLi(candidates[i], {
                domainMappers,
                filter: query,
                document,
                textSnippet,
                asOption: false,
            });
            if (myToken !== renderToken) return false;
            if (li) frag.append(li);
        }
        if (myToken !== renderToken) return false;
        /** @type {NonNullable<typeof listEl>} */ (listEl).append(frag);
        return true;
    };

    // Pre-warm bucket loads for the candidates we're about to render. Each full-text
    // result's `renderCandidateLi` awaits `loadBucket(ref)`, which injects a
    // `<script src="searchIndex_N.js">` for uncached buckets; without pre-warming,
    // the serial `await` below turns N distinct buckets into N serial round-trips.
    // `loadBucket` dedups repeat calls for the same bucket, so firing these in a loop
    // is safe — duplicate refs resolve to the same in-flight promise. Even for
    // already-cached buckets this matters, because browsers still validate
    // `<script src>` loads over the network.
    for (let i = 0; i < Math.min(n, EAGER); i++) {
        const c = candidates[i];
        if (c.kind === "fullText") getDocContentsFor(c.textMatch.ref).catch(() => {});
    }

    // Eager pass: mount the first `EAGER` results without yielding between chunks.
    // These are what the user sees above the fold, so latency matters more than
    // cooperativeness here. The token check inside `renderChunk` still bails out if
    // the user starts another query.
    const eagerEnd = Math.min(n, EAGER);
    for (let start = 0; start < eagerEnd; start += CHUNK) {
        if (!(await renderChunk(start, Math.min(start + CHUNK, eagerEnd)))) return;
    }

    // Tail pass: idle-scheduled, chunked, with a yield between chunks so the main
    // thread stays responsive. Navigation is handled by the inner
    // `<a class="search-result-link">` emitted by `renderCandidateLi`, so no click
    // listener is needed here — middle-click, open-in-new-tab, and keyboard Enter
    // all work via the anchor's default behaviour.
    if (n > EAGER) {
        const schedule =
            /** @type {any} */ (window).requestIdleCallback ??
            ((/** @type {() => void} */ fn) => setTimeout(fn, 200));
        schedule(
            async () => {
                if (myToken !== renderToken) return;
                // Same pre-warm as the eager phase — fire all tail bucket loads in
                // parallel before starting the serial render loop.
                for (let i = EAGER; i < n; i++) {
                    const c = candidates[i];
                    if (c.kind === "fullText") {
                        getDocContentsFor(c.textMatch.ref).catch(() => {});
                    }
                }
                for (let start = EAGER; start < n; start += CHUNK) {
                    if (myToken !== renderToken) return;
                    const ok = await renderChunk(start, Math.min(start + CHUNK, n));
                    if (!ok) return;
                    // Hand the main thread back to the scheduler between chunks.
                    await new Promise((r) => setTimeout(r, 0));
                }
            },
            { timeout: 500 },
        );
    }
};

/**
 * Update the URL's `q` parameter in place without a page reload, so the address bar
 * reflects the currently displayed results (share/bookmark/back work).
 *
 * @param {string} query
 */
const syncUrl = (query) => {
    const url = new URL(window.location.href);
    if (query) {
        url.searchParams.set("q", query);
    } else {
        url.searchParams.delete("q");
    }
    window.history.replaceState(null, "", url.toString());
};

/**
 * Build the plain search input inside the host element. We use a native
 * `<input type="search">` (not the quick-jump combobox): the live-updating list below
 * is already showing every result, so a dropdown on top of it would be redundant.
 *
 * @param {HTMLElement} host
 * @param {string} initialValue
 * @return {HTMLInputElement}
 */
const mountInput = (host, initialValue) => {
    const input = document.createElement("input");
    input.type = "search";
    input.id = "search-page-input";
    input.className = "search-page-input";
    input.placeholder = "Search…";
    input.autocapitalize = "none";
    input.autocomplete = "off";
    input.spellcheck = false;
    input.setAttribute("aria-label", "Search");
    input.value = initialValue;
    host.append(input);
    return input;
};

/**
 * Build the filter checkboxes: one per known domain (label = the domain's `displayName`)
 * plus a trailing one for the full-text search stream. Toggling any box triggers an
 * in-place re-render of the current query.
 *
 * @param {HTMLElement} container
 * @param {() => string} readQuery  Returns the current input value so re-renders stay in sync.
 */
const mountFilters = (container, readQuery) => {
    /**
     * @param {string} labelText
     * @param {boolean} initial
     * @param {(isChecked: boolean) => void} onChange
     */
    const makeCheckbox = (labelText, initial, onChange) => {
        const label = document.createElement("label");
        label.className = "search-page-filter";
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = initial;
        cb.addEventListener("change", () => {
            onChange(cb.checked);
            renderResultsFor(readQuery());
        });
        label.append(cb, " ", labelText);
        container.append(label);
        return { cb, label };
    };

    // Full-text comes first (it's orthogonal to the domain-specific ones), then the
    // domains are sorted by display name so the ordering is stable across runs.
    filterElements.fullText = makeCheckbox("Full-text", filters.fullText, (checked) => {
        filters.fullText = checked;
    });
    const sortedDomains = Object.entries(domainMappers).sort(([, a], [, b]) =>
        a.displayName.localeCompare(b.displayName),
    );
    for (const [id, mapper] of sortedDomains) {
        filterElements.domains[id] = makeCheckbox(
            mapper.displayName,
            filters.domains.has(id),
            (checked) => {
                if (checked) filters.domains.add(id);
                else filters.domains.delete(id);
            },
        );
    }
};

/**
 * Gray out + disable any checkbox whose bucket has zero hits in the current (unfiltered)
 * candidate pool, so users don't waste a click on filters that would change nothing.
 * A box the user has already unchecked stays unchecked, but still gets disabled when
 * there's nothing to toggle it back onto.
 *
 * @param {{fullText: number, domains: Record<string, number>}} counts
 */
const updateFilterDisabled = (counts) => {
    /**
     * @param {{ cb: HTMLInputElement, label: HTMLLabelElement } | null} entry
     * @param {number} count
     */
    const setState = (entry, count) => {
        if (!entry) return;
        const disabled = count === 0;
        entry.cb.disabled = disabled;
        entry.label.classList.toggle("search-page-filter--disabled", disabled);
    };
    setState(filterElements.fullText, counts.fullText);
    for (const id of Object.keys(filterElements.domains)) {
        setState(filterElements.domains[id], counts.domains[id] ?? 0);
    }
};

/** Reset all filter checkboxes to enabled (used when the query is empty). */
const clearFilterDisabled = () => {
    /**
     * @param {{ cb: HTMLInputElement, label: HTMLLabelElement } | null} entry
     */
    const clear = (entry) => {
        if (!entry) return;
        entry.cb.disabled = false;
        entry.label.classList.remove("search-page-filter--disabled");
    };
    clear(filterElements.fullText);
    for (const id of Object.keys(filterElements.domains)) clear(filterElements.domains[id]);
};

/**
 * clearTimeout for the input debouncer
 * @type {number | undefined}
 */
let debounceTimer = undefined;

const init = async () => {
    const host = /** @type {HTMLElement | null} */ (document.querySelector(".search-page-host"));
    const resultsRoot = document.getElementById("search-page-results");
    if (!host || !resultsRoot) return;

    const initialQuery = new URLSearchParams(window.location.search).get("q")?.trim() ?? "";
    const input = mountInput(host, initialQuery);

    // Filter row lives between the input and the results, above the count, so users
    // see what's being narrowed before the count.
    const filtersEl = document.createElement("div");
    filtersEl.className = "search-page-filters";
    filtersEl.setAttribute("role", "group");
    filtersEl.setAttribute("aria-label", "Filter results");
    resultsRoot.append(filtersEl);
    mountFilters(filtersEl, () => input.value.trim());

    // Result count lives above the results list so it's visible even when the list is
    // short or empty. `aria-live="polite"` makes screen readers announce count changes
    // (e.g. "12 results") as the user types.
    countEl = document.createElement("p");
    countEl.id = "search-page-count";
    countEl.className = "search-page-count muted";
    countEl.setAttribute("aria-live", "polite");
    resultsRoot.append(countEl);

    // The shared `verso-search-results` class lets the domain-specific CSS (emitted
    // into `domain-display.css`) match here as well as inside the combobox. No
    // `role="listbox"`: results are navigated by tabbing through the `<a>` inside
    // each `<li>`, not via arrow-key selection with `aria-activedescendant`. A
    // listbox role without those semantics misleads assistive tech into announcing
    // a selectable set that doesn't exist.
    listEl = document.createElement("ul");
    listEl.className = "search-page-list verso-search-results";
    resultsRoot.append(listEl);

    await renderResultsFor(initialQuery);

    input.addEventListener("input", () => {
        const q = input.value.trim();
        syncUrl(q);
        if (debounceTimer) window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(() => {
            renderResultsFor(q);
        }, 120);
    });

    // Enter on a standalone input would submit a form if there were one; there isn't.
    // Live-update already covers typing, so just prevent any implicit form submission.
    input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") e.preventDefault();
    });

    // Focus the input only when the page loaded without a query so the user can start
    // typing immediately. For direct links (`?q=foo`), leave focus alone so the user
    // can scroll and read results without fighting the browser for focus.
    if (!initialQuery) input.focus();
};

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
} else {
    init();
}
